package pages;

import com.cognizant.framework.Status;
import com.cognizant.framework.selenium.ReusableLibrary;
import org.openqa.selenium.By;

public class CommonMethods extends ReusableLibrary {

    public CommonMethods(ScriptHelper scriptHelper) {
        super(scriptHelper);
    }

    /**
     * Clicks on the specified button or element
     * @param elementLocator The locator of the element to be clicked
     * @param elementName The name of the element (for reporting purposes)
     */
    public void clickButton(By elementLocator, String elementName) {
        try {
            driver.findElement(elementLocator).click();
            report.updateTestLog("Click " + elementName, "Clicked on the '" + elementName + "' button", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Click " + elementName, "Failed to click on the '" + elementName + "' button", Status.FAIL);
        }
    }
}