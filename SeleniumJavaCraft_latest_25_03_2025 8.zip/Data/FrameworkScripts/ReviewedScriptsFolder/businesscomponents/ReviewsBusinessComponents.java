package businesscomponents;

import com.cognizant.core.ReusableLibrary;
import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import org.testng.Assert;
import pages.ReviewsPage;

public class ReviewsBusinessComponents extends ReusableLibrary {

    private final ReviewsPage reviewsPage;

    public ReviewsBusinessComponents(ScriptHelper scriptHelper) {
        super(scriptHelper);
        reviewsPage = new ReviewsPage(scriptHelper);
    }

    public void validateReviewsNavigation() {
        try {
            Assert.assertTrue(reviewsPage.isHeaderinVisiblePort());
            report.updateTestLog("Validate visibility of Reviews header", "Validate visibility of Reviews header", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Validate visibility of Reviews header", e, Status.FAIL);
        }
    }

    public void validateNextReviewsFunctionality() {
        try {
            String currentReview = reviewsPage.getReview();
            reviewsPage.clickNext();
            String nextReview = reviewsPage.getReview();

            if(currentReview.isEmpty() || nextReview.isEmpty()) {
                Assert.fail("Reviews are empty");
            } else {
                Assert.assertNotEquals(currentReview, nextReview);
            }
            report.updateTestLog("Validate change in review", "Validate change in review", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Validate change in review", e, Status.FAIL);
        }
    }

}
