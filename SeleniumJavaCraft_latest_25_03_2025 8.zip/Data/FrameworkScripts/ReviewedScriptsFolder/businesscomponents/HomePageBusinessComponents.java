package businesscomponents;

import com.cognizant.core.ReusableLibrary;
import com.cognizant.core.ScriptHelper;
import pages.HomePage;

public class HomePageBusinessComponents extends ReusableLibrary {

    private final HomePage homePage;

    public HomePageBusinessComponents(ScriptHelper scriptHelper) {
        super(scriptHelper);
        homePage = new HomePage(scriptHelper);
    }

    public HomePage getHomePage() {
        return homePage;
    }

}
