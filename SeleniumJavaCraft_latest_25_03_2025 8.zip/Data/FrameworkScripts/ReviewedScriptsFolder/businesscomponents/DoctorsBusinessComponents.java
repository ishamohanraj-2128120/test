package businesscomponents;

import com.cognizant.core.ReusableLibrary;
import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import org.testng.Assert;
import pages.DoctorsPage;

public class DoctorsBusinessComponents extends ReusableLibrary {

    private final DoctorsPage doctorsPage;

    public DoctorsBusinessComponents(ScriptHelper scriptHelper) {
        super(scriptHelper);
        doctorsPage = new DoctorsPage(scriptHelper);
    }

    public void validateDoctorsNavigation() {
        try {
            Assert.assertTrue(doctorsPage.isHeaderinVisiblePort());
            report.updateTestLog("Validate visibility of Doctors header", "Validate visibility of Doctors header", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Validate visibility of Doctors header", e, Status.FAIL);
        }
    }

    public void validateCardsnNames() {
        try {
            Assert.assertEquals(doctorsPage.getDoctorCards().size(), doctorsPage.getDoctorNames().size());
            report.updateTestLog("Validate Doctor names", "Validate presence of Doctor names for all Doctor Cards", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Validate Doctor names", e, Status.FAIL);
        }
    }
}
