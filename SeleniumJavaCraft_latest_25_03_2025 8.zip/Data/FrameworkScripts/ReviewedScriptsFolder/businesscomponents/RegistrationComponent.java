package businesscomponents;

import com.cognizant.core.ReusableLibrary;
import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import pages.RegistrationPage;

public class RegistrationComponent extends ReusableLibrary {

    private final RegistrationPage registrationPage;

    /**
     * Constructor to initialize the {@link ScriptHelper} object and in turn the
     * objects wrapped by it
     *
     * @param scriptHelper The {@link ScriptHelper} object
     */
    public RegistrationComponent(ScriptHelper scriptHelper) {
        super(scriptHelper);
        registrationPage = new RegistrationPage(scriptHelper);
    }

    /**
     * Method to enter registration details
     * @param firstName: First Name
     * @param lastName: Last Name
     * @param gender: Gender
     * @param phone: Phone
     * @param address: Address
     * @param city: City
     * @param state: State
     * @param zip: Zip
     */
    public void enterRegistrationDetails(String firstName, String  lastName, String gender, String phone, String address, String city, String state, String zip) {
        try {
            registrationPage.enterFirstName(firstName);
            registrationPage.enterLastName(lastName);
            registrationPage.selectGender(gender);
            registrationPage.enterPhone(phone);
            registrationPage.enterAddress(address);
            registrationPage.enterCity(city);
            registrationPage.enterState(state);
            registrationPage.enterZip(zip);
            report.updateTestLog("Enter Registration Details", "Registration Details entered successfully", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Enter Registration Details", e.getMessage(), Status.FAIL);
        }
    }

    /**
     * Method to validate registration
     * @return boolean
     */
    public boolean validateRegistration() {
        try {
            registrationPage.clickRegister();
            return registrationPage.isRegistrationSuccessful();
        } catch (Exception e) {
            report.updateTestLog("Validate Registration", e.getMessage(), Status.FAIL);
            return false;
        }
    }
}
