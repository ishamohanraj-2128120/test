package businesscomponents;

import com.cognizant.core.ReusableLibrary;
import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import org.testng.Assert;
import pages.AboutPage;

public class AboutBusinessComponents extends ReusableLibrary {

    private final AboutPage aboutPage;

    public AboutBusinessComponents(ScriptHelper scriptHelper) {
        super(scriptHelper);
        aboutPage = new AboutPage(scriptHelper);
    }

    public void validateAboutNavigation() {
        try {
            Assert.assertTrue(aboutPage.isHeaderinVisiblePort());
            report.updateTestLog("Validate visibility of About header", "Validate visibility of About header", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Validate visibility of About header", e, Status.FAIL);
        }
    }
}
