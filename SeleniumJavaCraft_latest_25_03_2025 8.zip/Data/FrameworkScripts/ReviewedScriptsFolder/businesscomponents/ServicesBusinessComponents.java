package businesscomponents;

import com.cognizant.core.ReusableLibrary;
import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import org.testng.Assert;
import pages.ServicesPage;

public class ServicesBusinessComponents extends ReusableLibrary {

    private final ServicesPage servicesPage;

    public ServicesBusinessComponents(ScriptHelper scriptHelper) {
        super(scriptHelper);
        servicesPage = new ServicesPage(scriptHelper);
    }

    public void validateServiceNavigation() {
        try {
            Assert.assertTrue(servicesPage.isHeaderinVisiblePort());
            report.updateTestLog("Validate visibility of Services header", "Validate visibility of Services header", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Validate visibility of Services header", e, Status.FAIL);
        }
    }

}
