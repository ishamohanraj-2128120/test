package testscripts.NavigationScenario;

import businesscomponents.DoctorsBusinessComponents;
import businesscomponents.HomePageBusinessComponents;
import com.cognizant.core.DriverScript;
import com.cognizant.core.TestConfigurationsLite;
import com.cognizant.framework.Status;
import com.cognizant.framework.selenium.SeleniumTestParameters;
import org.testng.annotations.Test;

public class TestDoctorsPageNavigation extends TestConfigurationsLite {

    private HomePageBusinessComponents homePageComponents;
    private DoctorsBusinessComponents doctorsBusinessComponents;

    @Test(dataProvider = "ChromeBrowser", dataProviderClass = TestConfigurationsLite.class)
    public void testDoctorsNavigation(SeleniumTestParameters testParameters) {
        testParameters.setCurrentTestDescription("Test Navigation to Doctors Page");
        DriverScript driverScript = new DriverScript(testParameters);
        driverScript.driveTestExecution();
        tearDownTestRunner(testParameters, driverScript);
    }

    @Override
    public void setUp() {
        driver.get("http://34.217.237.141:3003/banking-app");
        homePageComponents = new HomePageBusinessComponents(scriptHelper);
        doctorsBusinessComponents = new DoctorsBusinessComponents(scriptHelper);
    }

    @Override
    public void executeTest() {
        homePageComponents.getHomePage().clickServices();
        doctorsBusinessComponents.validateDoctorsNavigation();
    }

    @Override
    public void tearDown() {
        report.updateTestLog("Validation of Doctors Page Navigation", "Validate navigation to doctors page", Status.DONE);
        super.tearDown();
    }

}
