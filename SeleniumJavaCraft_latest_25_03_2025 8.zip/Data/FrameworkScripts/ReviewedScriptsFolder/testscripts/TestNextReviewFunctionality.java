package testscripts.ReviewValidationScenario;

import businesscomponents.HomePageBusinessComponents;
import businesscomponents.ReviewsBusinessComponents;
import com.cognizant.core.DriverScript;
import com.cognizant.core.TestConfigurationsLite;
import com.cognizant.framework.Status;
import com.cognizant.framework.selenium.SeleniumTestParameters;
import org.testng.annotations.Test;

public class TestNextReviewFunctionality extends TestConfigurationsLite {

    private HomePageBusinessComponents homePageComponents;
    private ReviewsBusinessComponents reviewsBusinessComponents;

    @Test(dataProvider = "ChromeBrowser", dataProviderClass = TestConfigurationsLite.class)
    public void testNextReviewFunctionality(SeleniumTestParameters testParameters) {
        testParameters.setCurrentTestDescription("Test next review functionality");
        DriverScript driverScript = new DriverScript(testParameters);
        driverScript.driveTestExecution();
        tearDownTestRunner(testParameters, driverScript);
    }

    @Override
    public void setUp() {
        driver.get("http://34.217.237.141:3003/banking-app");
        homePageComponents = new HomePageBusinessComponents(scriptHelper);
        reviewsBusinessComponents = new ReviewsBusinessComponents(scriptHelper);
    }

    @Override
    public void executeTest() {
        homePageComponents.getHomePage().clickReviews();
        reviewsBusinessComponents.validateNextReviewsFunctionality();
    }

    @Override
    public void tearDown() {
        report.updateTestLog("Validation of Services Page Navigation", "Validate navigation to services page", Status.DONE);
        super.tearDown();
    }

}
