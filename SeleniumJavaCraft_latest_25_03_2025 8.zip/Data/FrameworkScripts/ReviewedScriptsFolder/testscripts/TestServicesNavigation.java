package testscripts.NavigationScenario;

import businesscomponents.HomePageBusinessComponents;
import businesscomponents.ServicesBusinessComponents;
import com.cognizant.core.DriverScript;
import com.cognizant.core.TestConfigurationsLite;
import com.cognizant.framework.Status;
import com.cognizant.framework.selenium.SeleniumTestParameters;
import org.testng.annotations.Test;

public class TestServicesNavigation extends TestConfigurationsLite {

    private HomePageBusinessComponents homePageComponents;
    private ServicesBusinessComponents servicesBusinessComponents;

    @Test(dataProvider = "ChromeBrowser", dataProviderClass = TestConfigurationsLite.class)
    public void testServicesNavigation(SeleniumTestParameters testParameters) {
        testParameters.setCurrentTestDescription("Test Navigation to Services Page");
        DriverScript driverScript = new DriverScript(testParameters);
        driverScript.driveTestExecution();
        tearDownTestRunner(testParameters, driverScript);
    }

    @Override
    public void setUp() {
        driver.get("http://34.217.237.141:3003/banking-app");
        homePageComponents = new HomePageBusinessComponents(scriptHelper);
        servicesBusinessComponents = new ServicesBusinessComponents(scriptHelper);
    }

    @Override
    public void executeTest() {
        homePageComponents.getHomePage().clickServices();
        servicesBusinessComponents.validateServiceNavigation();
    }

    @Override
    public void tearDown() {
        report.updateTestLog("Validation of Services Page Navigation", "Validate navigation to services page", Status.DONE);
        super.tearDown();
    }
}
