package testscripts;

import businesscomponents.RegistrationComponent;
import com.cognizant.core.DriverScript;
import com.cognizant.core.TestConfigurationsLite;
import com.cognizant.framework.Settings;
import com.cognizant.framework.Status;
import com.cognizant.framework.selenium.SeleniumTestParameters;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestSuccessfulRegistration extends TestConfigurationsLite {

    private RegistrationComponent registrationComponent;

    @Test(dataProvider = "ChromeBrowser", dataProviderClass = TestConfigurationsLite.class)
    public void testNextReviewFunctionality(SeleniumTestParameters testParameters) {
        testParameters.setCurrentTestDescription("Validate registration functionality");
        DriverScript driverScript = new DriverScript(testParameters);
        driverScript.driveTestExecution();
        tearDownTestRunner(testParameters, driverScript);
    }

    @Override
    public void setUp() {
        driver.get(Settings.getInstance().getProperty("ApplicationUrl"));
        registrationComponent = new RegistrationComponent(scriptHelper);
    }

    @Override
    public void executeTest() {
        registrationComponent.enterRegistrationDetails(
                dataTable.getData("Registration", "FirstName"),
                dataTable.getData("Registration", "LastName"),
                dataTable.getData("Registration", "Gender"),
                dataTable.getData("Registration", "Phone"),
                dataTable.getData("Registration", "Address"),
                dataTable.getData("Registration", "City"),
                dataTable.getData("Registration", "State"),
                dataTable.getData("Registration", "Zip")
        );
        Assert.assertTrue(registrationComponent.validateRegistration(), "Registration failed");
    }

    @Override
    public void tearDown() {
        report.updateTestLog("Validation of Services Page Navigation", "Validate navigation to services page", Status.DONE);
    }

}
