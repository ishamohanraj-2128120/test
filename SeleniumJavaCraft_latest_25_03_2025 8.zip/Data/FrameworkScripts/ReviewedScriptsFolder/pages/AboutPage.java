package pages;

import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;

public class AboutPage extends MasterPage {

    private final By header = By.className("about-title");

    public AboutPage(ScriptHelper scriptHelper) {
        super(scriptHelper);
    }

    public boolean isHeaderinVisiblePort() {
        boolean flag = false;
        try {
            flag = isVisibleInViewport(driver.findElement(header));
            report.updateTestLog("Check whether About header is visisble", "Check whether About header is visisble", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Check whether About header is visisble", e, Status.FAIL);
        }
        return flag;
    }
}
