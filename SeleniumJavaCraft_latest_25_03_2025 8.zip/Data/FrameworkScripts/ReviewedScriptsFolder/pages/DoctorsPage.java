package pages;

import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class DoctorsPage extends MasterPage {

    private final By header = By.className("dt-title");
    private final By doctorCards = By.className("dt-card");
    private final By doctorNames = By.className("dt-card-name");

    public DoctorsPage(ScriptHelper scriptHelper) {
        super(scriptHelper);
    }

    public boolean isHeaderinVisiblePort() {
        boolean flag = false;
        try {
            flag = isVisibleInViewport(driver.findElement(header));
            report.updateTestLog("Check whether Doctors header is visisble", "Check whether Doctors header is visisble", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Check whether Doctors header is visisble", e, Status.FAIL);
        }
        return flag;
    }

    public List<WebElement> getDoctorCards() {
        return driver.findElements(doctorCards);
    }

    public List<String> getDoctorNames() {
        List<String> doctorNames = new ArrayList<>();
        try {
            doctorNames.addAll(
                    driver.findElements(this.doctorNames).stream().map(t -> t.getText().strip()).collect(Collectors.toList())
            );
            report.updateTestLog("Get doctor names", "Get doctor names", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Get doctor names", e, Status.FAIL);
        }
        return doctorNames;
    }

}
