/**
 * This class represents the History Page of the application.
 * It contains methods to interact with the web elements on the page.
 */
package pages;

import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import com.cognizant.framework.WebDriverUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

public class HistoryPage {

    private ScriptHelper scriptHelper;
    private WebDriverUtil driverUtil;
    private WebDriverWait wait;
    private Logger logger;

    @FindBy(tagName = "input")
    private WebElement allergiesInput;

    @FindBy(tagName = "input")
    private WebElement currentMedicationsInput;

    @FindBy(tagName = "input")
    private WebElement pastSurgeriesInput;

    @FindBy(tagName = "button")
    private WebElement nextButton;

    /**
     * Constructor to initialize the HistoryPage object.
     * @param scriptHelper The ScriptHelper object.
     */
    public HistoryPage(ScriptHelper scriptHelper) {
        this.scriptHelper = scriptHelper;
        this.driverUtil = scriptHelper.getDriverUtil();
        this.wait = new WebDriverWait(scriptHelper.getcustomDriver(), 10);
        this.logger = Logger.getLogger(HistoryPage.class.getName());
        PageFactory.initElements(scriptHelper.getcustomDriver(), this);
    }

    /**
     * Method to populate the Allergies input field.
     * @param testData The test data for the input field.
     */
    public void populateAllergies(String testData) {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(allergiesInput));
            allergiesInput.sendKeys(testData);
            logger.info("Allergies input field populated with: " + testData);
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Populate Allergies", "Failed to populate Allergies input field", Status.FAIL);
            logger.error("Failed to populate Allergies input field: " + e.getMessage());
        }
    }

    /**
     * Method to populate the Current Medications input field.
     * @param testData The test data for the input field.
     */
    public void populateCurrentMedications(String testData) {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(currentMedicationsInput));
            currentMedicationsInput.sendKeys(testData);
            logger.info("Current Medications input field populated with: " + testData);
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Populate Current Medications", "Failed to populate Current Medications input field", Status.FAIL);
            logger.error("Failed to populate Current Medications input field: " + e.getMessage());
        }
    }

    /**
     * Method to populate the Past Surgeries or Medical Procedures input field.
     * @param testData The test data for the input field.
     */
    public void populatePastSurgeries(String testData) {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(pastSurgeriesInput));
            pastSurgeriesInput.sendKeys(testData);
            logger.info("Past Surgeries input field populated with: " + testData);
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Populate Past Surgeries", "Failed to populate Past Surgeries input field", Status.FAIL);
            logger.error("Failed to populate Past Surgeries input field: " + e.getMessage());
        }
    }

    /**
     * Method to click on the Next button.
     */
    public void clickNext() {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(nextButton));
            nextButton.click();
            logger.info("Next button clicked");
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Click Next", "Failed to click Next button", Status.FAIL);
            logger.error("Failed to click Next button: " + e.getMessage());
        }
    }
}