/**
 * This class represents the Billing Page of the application.
 * It contains methods to interact with the web elements on the Billing Page.
 */
package pages;

import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import com.cognizant.framework.WebDriverUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

public class BillingPage {

    private ScriptHelper scriptHelper;
    private WebDriverUtil driverUtil;
    private WebDriverWait wait;
    private Logger logger;

    @FindBy(tagName = "input")
    private WebElement creditCardInformationInput;

    @FindBy(tagName = "input")
    private WebElement nameOnCardInput;

    @FindBy(tagName = "button")
    private WebElement confirmAppointmentButton;

    /**
     * Constructor to initialize the BillingPage object.
     * @param scriptHelper The ScriptHelper object.
     */
    public BillingPage(ScriptHelper scriptHelper) {
        this.scriptHelper = scriptHelper;
        this.driverUtil = scriptHelper.getDriverUtil();
        this.wait = new WebDriverWait(scriptHelper.getcustomDriver(), 10);
        this.logger = Logger.getLogger(BillingPage.class.getName());
        PageFactory.initElements(scriptHelper.getcustomDriver(), this);
    }

    /**
     * Method to populate the credit card information.
     * @param testData The test data for credit card information.
     */
    public void populateCreditCardInformation(String testData) {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(creditCardInformationInput));
            creditCardInformationInput.sendKeys(testData);
            logger.info("Credit card information populated successfully.");
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Populate Credit Card Information", "Failed to populate credit card information", Status.FAIL);
            logger.error("Failed to populate credit card information: " + e.getMessage());
        }
    }

    /**
     * Method to populate the name on card.
     * @param testData The test data for name on card.
     */
    public void populateNameOnCard(String testData) {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(nameOnCardInput));
            nameOnCardInput.sendKeys(testData);
            logger.info("Name on card populated successfully.");
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Populate Name on Card", "Failed to populate name on card", Status.FAIL);
            logger.error("Failed to populate name on card: " + e.getMessage());
        }
    }

    /**
     * Method to click on the confirm appointment button.
     */
    public void clickConfirmAppointment() {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(confirmAppointmentButton));
            confirmAppointmentButton.click();
            logger.info("Confirm appointment button clicked successfully.");
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Click Confirm Appointment", "Failed to click confirm appointment button", Status.FAIL);
            logger.error("Failed to click confirm appointment button: " + e.getMessage());
        }
    }
}