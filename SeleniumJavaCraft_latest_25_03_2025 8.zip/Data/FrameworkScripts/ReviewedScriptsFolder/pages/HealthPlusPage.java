/**
 * This class represents the HealthPlusPage in the application.
 * It contains methods to interact with the web elements on the page.
 */
package pages;

import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import com.cognizant.framework.WebDriverUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

public class HealthPlusPage {

    private ScriptHelper scriptHelper;
    private WebDriverUtil driverUtil;
    private WebDriverWait wait;
    private Logger logger;

    @FindBy(tagName = "button")
    private WebElement bookAppointmentButton;

    /**
     * Constructor to initialize the HealthPlusPage object
     * @param scriptHelper The ScriptHelper object
     */
    public HealthPlusPage(ScriptHelper scriptHelper) {
        this.scriptHelper = scriptHelper;
        this.driverUtil = scriptHelper.getDriverUtil();
        this.wait = new WebDriverWait(scriptHelper.getcustomDriver(), 10);
        this.logger = Logger.getLogger(HealthPlusPage.class.getName());
        PageFactory.initElements(scriptHelper.getcustomDriver(), this);
    }

    /**
     * Method to navigate to the HealthPlus page
     */
    public void navigateToHealthPlusPage() {
        try {
            scriptHelper.getcustomDriver().get("http://34.217.237.141:3004/Health-Plus");
            logger.info("URL launched successfully.");
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Navigate to HealthPlus Page", "Failed to navigate to HealthPlus page", Status.FAIL);
            logger.error("Failed to navigate to HealthPlus page");
        }
    }

    /**
     * Method to click on the Book Appointment button
     */
    public void clickBookAppointmentButton() {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(bookAppointmentButton));
            bookAppointmentButton.click();
            logger.info("Clicked on Book Appointment button");
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Click Book Appointment Button", "Failed to click on Book Appointment button", Status.FAIL);
            logger.error("Failed to click on Book Appointment button");
        }
    }
}