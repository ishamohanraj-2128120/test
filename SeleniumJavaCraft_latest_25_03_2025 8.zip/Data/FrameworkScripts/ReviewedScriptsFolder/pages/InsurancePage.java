/**
 * This class represents the Insurance Page of the application.
 * It contains methods to interact with the web elements on the page.
 */
package pages;

import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import com.cognizant.framework.WebDriverUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

public class InsurancePage {

    private ScriptHelper scriptHelper;
    private WebDriverUtil driverUtil;
    private WebDriverWait wait;
    private Logger logger;

    @FindBy(tagName = "input")
    private WebElement insuranceProviderInput;

    @FindBy(tagName = "input")
    private WebElement policyNumberInput;

    @FindBy(tagName = "input")
    private WebElement groupNumberInput;

    @FindBy(tagName = "button")
    private WebElement nextButton;

    /**
     * Constructor to initialize the InsurancePage object
     * @param scriptHelper The ScriptHelper object
     */
    public InsurancePage(ScriptHelper scriptHelper) {
        this.scriptHelper = scriptHelper;
        this.driverUtil = scriptHelper.getDriverUtil();
        this.wait = new WebDriverWait(scriptHelper.getcustomDriver(), 10);
        this.logger = Logger.getLogger(InsurancePage.class.getName());
        PageFactory.initElements(scriptHelper.getcustomDriver(), this);
    }

    /**
     * Method to populate the Insurance Provider field
     */
    public void populateInsuranceProvider() {
        try {
            insuranceProviderInput.sendKeys(scriptHelper.getDataTable().getData("DataSheet", "Insurance Provider"));
            logger.info("Insurance Provider field populated successfully.");
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Populate Insurance Provider", "Failed to populate Insurance Provider field", Status.FAIL);
            logger.error("Failed to populate Insurance Provider field.", e);
        }
    }

    /**
     * Method to populate the Policy Number field
     */
    public void populatePolicyNumber() {
        try {
            policyNumberInput.sendKeys(scriptHelper.getDataTable().getData("DataSheet", "Policy Number"));
            logger.info("Policy Number field populated successfully.");
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Populate Policy Number", "Failed to populate Policy Number field", Status.FAIL);
            logger.error("Failed to populate Policy Number field.", e);
        }
    }

    /**
     * Method to populate the Group Number field
     */
    public void populateGroupNumber() {
        try {
            groupNumberInput.sendKeys(scriptHelper.getDataTable().getData("DataSheet", "Group Number (if applicable)"));
            logger.info("Group Number field populated successfully.");
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Populate Group Number", "Failed to populate Group Number field", Status.FAIL);
            logger.error("Failed to populate Group Number field.", e);
        }
    }

    /**
     * Method to click on the Next button
     */
    public void clickNextButton() {
        try {
            nextButton.click();
            logger.info("Next button clicked successfully.");
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Click Next", "Failed to click Next button", Status.FAIL);
            logger.error("Failed to click Next button.", e);
        }
    }
}