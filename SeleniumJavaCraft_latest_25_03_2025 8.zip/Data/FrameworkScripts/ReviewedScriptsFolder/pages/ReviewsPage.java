package pages;

import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;

public class ReviewsPage extends MasterPage{

    private final By header = By.className("rw-text-desc");
    private final By review = By.className("rw-review");
    private final By nextButton = By.className("rw-next-btn");

    public ReviewsPage(ScriptHelper scriptHelper) {
        super(scriptHelper);
    }

    public boolean isHeaderinVisiblePort() {
        boolean flag = false;
        try {
            flag = isVisibleInViewport(driver.findElement(header));
            report.updateTestLog("Check whether Reviews header is visisble", "Check whether Reviews header is visisble", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Check whether Reviews header is visisble", e, Status.FAIL);
        }
        return flag;
    }

    public void clickNext() {
        try {
            driver.findElement(nextButton).click();
            report.updateTestLog("Click next review button", "Click next review button", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Click next review button", e, Status.FAIL);
        }
    }

    public String getReview() {
        String review = "";
        try {
            review = driver.findElement(this.review).getText().strip();
            report.updateTestLog("Get review", "Get review", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Get review", e, Status.FAIL);
        }
        return review;
    }
}
