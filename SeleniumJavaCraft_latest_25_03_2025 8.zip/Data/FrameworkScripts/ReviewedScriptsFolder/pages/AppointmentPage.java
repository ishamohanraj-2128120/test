/**
 * This class represents the Appointment Page of the application.
 * It contains methods to interact with the web elements on the page.
 */
package pages;

import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import com.cognizant.framework.WebDriverUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

public class AppointmentPage {

    private ScriptHelper scriptHelper;
    private WebDriverUtil driverUtil;
    private WebDriverWait wait;
    private Logger logger;

    @FindBy(tagName = "input")
    private WebElement patientFullNameInput;

    @FindBy(tagName = "input")
    private WebElement patientPhoneNumberInput;

    @FindBy(tagName = "option")
    private WebElement patientGenderOption;

    @FindBy(tagName = "input")
    private WebElement preferredAppointmentTimeInput;

    @FindBy(tagName = "option")
    private WebElement preferredModeOption;

    @FindBy(tagName = "button")
    private WebElement nextButton;

    /**
     * Constructor to initialize the AppointmentPage object.
     * @param scriptHelper The ScriptHelper object.
     */
    public AppointmentPage(ScriptHelper scriptHelper) {
        this.scriptHelper = scriptHelper;
        this.driverUtil = scriptHelper.getDriverUtil();
        this.wait = new WebDriverWait(scriptHelper.getcustomDriver(), 10);
        this.logger = Logger.getLogger(AppointmentPage.class.getName());
        PageFactory.initElements(scriptHelper.getcustomDriver(), this);
    }

    /**
     * Method to populate the patient full name.
     * @param fullName The full name of the patient.
     */
    public void populatePatientFullName(String fullName) {
        try {
            wait.until(ExpectedConditions.visibilityOf(patientFullNameInput));
            patientFullNameInput.sendKeys(fullName);
            logger.info("Patient full name populated successfully.");
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Populate Patient Full Name", "Failed to populate patient full name", Status.FAIL);
            logger.error("Failed to populate patient full name.", e);
        }
    }

    /**
     * Method to populate the patient phone number.
     * @param phoneNumber The phone number of the patient.
     */
    public void populatePatientPhoneNumber(String phoneNumber) {
        try {
            wait.until(ExpectedConditions.visibilityOf(patientPhoneNumberInput));
            patientPhoneNumberInput.sendKeys(phoneNumber);
            logger.info("Patient phone number populated successfully.");
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Populate Patient Phone Number", "Failed to populate patient phone number", Status.FAIL);
            logger.error("Failed to populate patient phone number.", e);
        }
    }

    /**
     * Method to select the patient gender.
     * @param gender The gender of the patient.
     */
    public void selectPatientGender(String gender) {
        try {
            wait.until(ExpectedConditions.visibilityOf(patientGenderOption));
            patientGenderOption.sendKeys(gender);
            logger.info("Patient gender selected successfully.");
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Select Patient Gender", "Failed to select patient gender", Status.FAIL);
            logger.error("Failed to select patient gender.", e);
        }
    }

    /**
     * Method to populate the preferred appointment time.
     * @param appointmentTime The preferred appointment time.
     */
    public void populatePreferredAppointmentTime(String appointmentTime) {
        try {
            wait.until(ExpectedConditions.visibilityOf(preferredAppointmentTimeInput));
            preferredAppointmentTimeInput.sendKeys(appointmentTime);
            logger.info("Preferred appointment time populated successfully.");
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Populate Preferred Appointment Time", "Failed to populate preferred appointment time", Status.FAIL);
            logger.error("Failed to populate preferred appointment time.", e);
        }
    }

    /**
     * Method to select the preferred mode.
     * @param mode The preferred mode.
     */
    public void selectPreferredMode(String mode) {
        try {
            wait.until(ExpectedConditions.visibilityOf(preferredModeOption));
            preferredModeOption.sendKeys(mode);
            logger.info("Preferred mode selected successfully.");
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Select Preferred Mode", "Failed to select preferred mode", Status.FAIL);
            logger.error("Failed to select preferred mode.", e);
        }
    }

    /**
     * Method to click on the Next button.
     */
    public void clickNext() {
        try {
            wait.until(ExpectedConditions.visibilityOf(nextButton));
            nextButton.click();
            logger.info("Next button clicked successfully.");
        } catch (Exception e) {
            scriptHelper.getReport().updateTestLog("Click Next", "Failed to click Next button", Status.FAIL);
            logger.error("Failed to click Next button.", e);
        }
    }
}