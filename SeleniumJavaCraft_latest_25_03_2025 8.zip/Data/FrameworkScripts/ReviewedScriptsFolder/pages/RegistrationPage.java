package pages;

import com.cognizant.core.ReusableLibrary;
import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

public class RegistrationPage extends ReusableLibrary {

    private static final By firstName = By.id("first-name");
    private static final By lastName = By.id("last-name");
    private static final By gender = By.id("gender");
    private static final By phone = By.id("phone");
    private static final By address = By.id("address");
    private static final By city = By.id("city");
    private static final By state = By.id("state");
    private static final By zip = By.id("zip");
    private static final By register = By.cssSelector(".submit-btn");
    private static final By successfulRegistration = By.id("successModal");


    /**
     * Constructor to initialize the {@link ScriptHelper} object and in turn the
     * objects wrapped by it
     *
     * @param scriptHelper The {@link ScriptHelper} object
     */
    public RegistrationPage(ScriptHelper scriptHelper) {
        super(scriptHelper);
    }

    /*
        * Method to enter first name
        * @param firstName
        * @return void
     */
    public void enterFirstName(String firstName) {
        try {
            driver.findElement(RegistrationPage.firstName).sendKeys(firstName);
        } catch (Exception e) {
            report.updateTestLog("Enter First Name", "First Name field not found", Status.FAIL);
        }
    }

    /*
        * Method to enter last name
        * @param lastName
        * @return void
     */
    public void enterLastName(String lastName) {
        try {
            driver.findElement(RegistrationPage.lastName).sendKeys(lastName);
        } catch (Exception e) {
            report.updateTestLog("Enter Last Name", "Last Name field not found", Status.FAIL);
        }
    }

    /*
        * Method to select gender
        * @param gender
        * @return void
     */
    public void selectGender(String gender) {
        try {
            Select genderDropdown = new Select(driver.findElement(RegistrationPage.gender));
            genderDropdown.selectByVisibleText(gender);
        } catch (Exception e) {
            report.updateTestLog("Select gender", "Selecting gender failed", Status.FAIL);
        }
    }

    /*
        * Method to enter phone number
        * @param phone
        * @return void
     */
    public void enterPhone(String phone) {
        try {
            driver.findElement(RegistrationPage.phone).sendKeys(phone);
        } catch (Exception e) {
            report.updateTestLog("Enter Phone", "Phone field not found", Status.FAIL);
        }
    }

    /*
        * Method to enter address
        * @param address
        * @return void
     */
    public void enterAddress(String address) {
        try {
            driver.findElement(RegistrationPage.address).sendKeys(address);
        } catch (Exception e) {
            report.updateTestLog("Enter Address", "Address field not found", Status.FAIL);
        }
    }

    /*
        * Method to enter city
        * @param city
        * @return void
     */
    public void enterCity(String city) {
        try {
            driver.findElement(RegistrationPage.city).sendKeys(city);
        } catch (Exception e) {
            report.updateTestLog("Enter City", "City field not found", Status.FAIL);
        }
    }

    /*
        * Method to enter state
        * @param state
        * @return void
     */
    public void enterState(String state) {
        try {
            driver.findElement(RegistrationPage.state).sendKeys(state);
        } catch (Exception e) {
            report.updateTestLog("Enter State", "State field not found", Status.FAIL);
        }
    }

    /*
        * Method to enter zip code
        * @param zip
        * @return void
     */
    public void enterZip(String zip) {
        try {
            driver.findElement(RegistrationPage.zip).sendKeys(zip);
        } catch (Exception e) {
            report.updateTestLog("Enter Zip", "Zip field not found", Status.FAIL);
        }
    }

    /*
        * Method to click on register button
        * @return void
     */
    public void clickRegister() {
        try {
            driver.findElement(RegistrationPage.register).click();
        } catch (Exception e) {
            report.updateTestLog("Click Register", "Register button not found", Status.FAIL);
        }
    }

    /*
        * Method to check if registration is successful
        * @return boolean
     */
    public boolean isRegistrationSuccessful() {
        try {
            return driver.findElement(RegistrationPage.successfulRegistration).isDisplayed();
        } catch (Exception e) {
            report.updateTestLog("Check Registration", "Registration not successful", Status.FAIL);
            return false;
        }
    }
}
