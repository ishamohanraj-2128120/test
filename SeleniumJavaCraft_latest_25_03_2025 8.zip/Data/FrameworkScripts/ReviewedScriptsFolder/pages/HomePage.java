package pages;

import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class HomePage extends MasterPage {

    private final By servicesLinkText = By.linkText("Services");
    private final By homeLinkText = By.linkText("Home");
    private final By aboutLinkText = By.linkText("About");
    private final By reviewsLinkText = By.linkText("Reviews");
    private final By doctorsLinkText = By.linkText("Doctors");

    public HomePage(ScriptHelper scriptHelper) {
        super(scriptHelper);
    }

    public void clickHome() {
        try {
            WebElement homeLinkText = driver.findElement(this.homeLinkText);
            scrollIntoView(homeLinkText);
            homeLinkText.click();
            report.updateTestLog("Click Home link navigation", "Click on Home link text", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Click Home link navigation", e, Status.FAIL);
        }
    }

    public void clickServices() {
        try {
            WebElement servicesLinkText = driver.findElement(this.servicesLinkText);
            scrollIntoView(servicesLinkText);
            servicesLinkText.click();
            report.updateTestLog("Click Services link navigation", "Click on Services link text", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Click Services link navigation", e, Status.FAIL);
        }
    }

    public void clickAbout() {
        try {
            WebElement aboutLinkText = driver.findElement(this.aboutLinkText);
            scrollIntoView(aboutLinkText);
            aboutLinkText.click();
            report.updateTestLog("Click About link navigation", "Click on About link text", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Click About link navigation", e, Status.FAIL);
        }
    }

    public void clickDoctors() {
        try {
            WebElement doctorsLinkText = driver.findElement(this.doctorsLinkText);
            scrollIntoView(doctorsLinkText);
            doctorsLinkText.click();
            report.updateTestLog("Click Doctors link navigation", "Click on Doctors link text", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Click Doctors link navigation", e, Status.FAIL);
        }
    }

    public void clickReviews() {
        try {
            WebElement reviewsLinkText = driver.findElement(this.reviewsLinkText);
            scrollIntoView(reviewsLinkText);
            reviewsLinkText.click();
            report.updateTestLog("Click Reviews link navigation", "Click on Reviews link text", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Click Reviews link navigation", e, Status.FAIL);
        }
    }

    public boolean isHomeinViewPort() {
        return isVisibleInViewport(driver.findElement(homeLinkText));
    }

    public boolean isServicesinViewPort() {
        return isVisibleInViewport(driver.findElement(homeLinkText));
    }

    public boolean isAboutinViewPort() {
        return isVisibleInViewport(driver.findElement(homeLinkText));
    }

    public boolean isReviewsinViewPort() {
        return isVisibleInViewport(driver.findElement(homeLinkText));
    }

    public boolean isDoctorsinViewPort() {
        return isVisibleInViewport(driver.findElement(homeLinkText));
    }


}
