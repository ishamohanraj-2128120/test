/**
 * ReasonPage class is used to perform actions on the Reason page of the application.
 * It extends the ReusableLibrary class and uses the Cognizant Reusable Automation Framework for Testing (CRAFT).
 */
package pages;

import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.cognizant.framework.WebDriverUtil;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

public class ReasonPage extends ReusableLibrary {
    
    private static final Logger LOGGER = Logger.getLogger(ReasonPage.class.getName());
    
    @FindBy(tagName = "input")
    private WebElement populatePrimaryHealthConcern;
    
    @FindBy(tagName = "input")
    private WebElement populateSymptomsOrSpecificIssues;
    
    @FindBy(tagName = "input")
    private WebElement populateAnyRelevantInformation;
    
    @FindBy(tagName = "button")
    private WebElement clickNext;
    
    /**
     * Constructor method for ReasonPage class.
     * @param scriptHelper The ScriptHelper object passed from the parent class.
     */
    public ReasonPage(ScriptHelper scriptHelper) {
        super(scriptHelper);
        PageFactory.initElements(driver, this);
    }
    
    /**
     * Method to populate the Primary Health Concern field.
     */
    public void populatePrimaryHealthConcern() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.visibilityOf(populatePrimaryHealthConcern));
            populatePrimaryHealthConcern.sendKeys(getDataTable("DataSheet", "Populate Primary Health Concern"));
            LOGGER.info("Primary Health Concern field populated successfully.");
        } catch (Exception e) {
            report.updateTestLog("Populate Primary Health Concern", "Failed to populate Primary Health Concern field", Status.FAIL);
            LOGGER.error("Failed to populate Primary Health Concern field", e);
        }
    }
    
    /**
     * Method to populate the Symptoms or Specific Issues field.
     */
    public void populateSymptomsOrSpecificIssues() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.visibilityOf(populateSymptomsOrSpecificIssues));
            populateSymptomsOrSpecificIssues.sendKeys(getDataTable("DataSheet", "Populate Symptoms or Specific Issues"));
            LOGGER.info("Symptoms or Specific Issues field populated successfully.");
        } catch (Exception e) {
            report.updateTestLog("Populate Symptoms or Specific Issues", "Failed to populate Symptoms or Specific Issues field", Status.FAIL);
            LOGGER.error("Failed to populate Symptoms or Specific Issues field", e);
        }
    }
    
    /**
     * Method to populate the Any Relevant Information for the doctor field.
     */
    public void populateAnyRelevantInformation() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.visibilityOf(populateAnyRelevantInformation));
            populateAnyRelevantInformation.sendKeys(getDataTable("DataSheet", "Populate Any relevant information for the doctor"));
            LOGGER.info("Any Relevant Information for the doctor field populated successfully.");
        } catch (Exception e) {
            report.updateTestLog("Populate Any relevant information for the doctor", "Failed to populate Any relevant information for the doctor field", Status.FAIL);
            LOGGER.error("Failed to populate Any relevant information for the doctor field", e);
        }
    }
    
    /**
     * Method to click on the Next button.
     */
    public void clickNext() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.visibilityOf(clickNext));
            clickNext.click();
            LOGGER.info("Next button clicked successfully.");
        } catch (Exception e) {
            report.updateTestLog("Click Next", "Failed to click on Next button", Status.FAIL);
            LOGGER.error("Failed to click on Next button", e);
        }
    }
}