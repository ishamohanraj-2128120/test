package pages;

import com.cognizant.core.ScriptHelper;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;

public class ServicesPage extends MasterPage {

    private final By header = By.className("info-title");

    public ServicesPage(ScriptHelper scriptHelper) {
        super(scriptHelper);
    }

    public boolean isHeaderinVisiblePort() {
        boolean flag = false;
        try {
            flag = isVisibleInViewport(driver.findElement(header));
            report.updateTestLog("Check whether Services header is visisble", "Check whether Services header is visisble", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Check whether Services header is visisble", e, Status.FAIL);
        }
        return flag;
    }

}
