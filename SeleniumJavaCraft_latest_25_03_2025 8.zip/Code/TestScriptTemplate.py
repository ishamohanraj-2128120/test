from Code.ChromaDBConnector import ChromaDBConnector

from Code.LLM import LLM
from Code.SeleniumJavaPrompt import SeleniumJavaPrompt


class TestScriptTemplate:

    def __init__(self, input_param):
        self.model = LLM()
        self.input_param = input_param

    def generate(self, page_name, comp_code):

        # prompt_decryption = PromptDecryption()
        prompt_instance = SeleniumJavaPrompt()
        # template_testscript_class = prompt_decryption.decrypt_prompt("template_testscript_class", prompt_instance)
        template_testscript_class = prompt_instance.template_testscript_class

        db = ChromaDBConnector("../Data/embed_data_core")

        reusable_code_details = ""
        if 'testscripts' in self.input_param['reusable_class_names'].keys():
            for class_name in self.input_param['reusable_class_names']['testscripts']:
                print(class_name)
                # reusable_code_details = reusable_code_details + db.get_doc_by_id(class_name)['documents'][0] + '\n'
                class_documents = db.get_doc_by_id(class_name)['documents']
                if class_documents:  # Check if the list is not empty
                    reusable_code_details += class_documents[0] + '\n'

        sample_method_to_follow = """@Test(dataProvider = "ChromeBrowser", dataProviderClass = TestConfigurationsLite.class)
                            public void testRunner(SeleniumTestParameters testParameters) {
                                testParameters.setCurrentTestDescription(<test description>);
        
                                DriverScript driverScript = new DriverScript(testParameters);
                                driverScript.driveTestExecution();
                                tearDownTestRunner(testParameters, driverScript);
                            }"""

        input_variables = ["reusable_code_details", "page_class",
                           "component_class", "sample_method_to_follow"]
        input_variables_dict = {'reusable_code_details': reusable_code_details, 'page_class': page_name,
                                'component_class': comp_code, 'sample_method_to_follow': sample_method_to_follow}
        output_qa_prompt_test = self.model.send_request(self.input_param, template_testscript_class, input_variables,
                                                        input_variables_dict)
        print("TestScript Class Generated")

        return output_qa_prompt_test
