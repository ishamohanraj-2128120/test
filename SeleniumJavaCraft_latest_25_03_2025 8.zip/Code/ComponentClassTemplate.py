from Code.ChromaDBConnector import ChromaDBConnector

from Code.LLM import LLM
from Code.SeleniumJavaPrompt import SeleniumJavaPrompt


class ComponentClassTemplate:

    def __init__(self, input_param):
        self.model = LLM()
        self.input_param = input_param

    def generate(self, page_name, page_data, pg_code):

        # prompt_decryption = PromptDecryption()
        prompt_instance = SeleniumJavaPrompt()
        # template_comp_class = prompt_decryption.decrypt_prompt("template_comp_class", prompt_instance)
        template_comp_class = prompt_instance.template_comp_class

        db = ChromaDBConnector("../Data/embed_data_core")

        reusable_code_details = ""
        for class_name in self.input_param['reusable_class_names']['businesscomponents']:
            class_documents = db.get_doc_by_id(class_name)['documents']
            if class_documents:  # Check if the list is not empty
                reusable_code_details += class_documents[0] + '\n'


        input_variables = ["reusable_code_details", "page_class", "pg_class"]
        input_variables_dict = {'reusable_code_details': reusable_code_details, 'page_class': page_name, 'pg_class': pg_code}

        output_qa_prompt_com = self.model.send_request(self.input_param, template_comp_class, input_variables,
                                                       input_variables_dict)
        print(f"{page_name}Component class file generated")
        return output_qa_prompt_com
