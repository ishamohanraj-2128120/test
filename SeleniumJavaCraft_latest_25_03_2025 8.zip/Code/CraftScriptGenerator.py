from Code.FileHandling import write_code_to_file
from Code.parseMethodToCsv import ParseMethodToCsv
from Code.ChromaDBConnector import ChromaDBConnector
from Code.PageClassTemplate import PageClassTemplate
from Code.ComponentClassTemplate import ComponentClassTemplate
from Code.TestScriptTemplate import TestScriptTemplate
from Code.RetrievalLayer import retrieve_exist_code
from Code import PathConstants

CRAFT_FRAMEWORK_PATH = PathConstants.CRAFT_FRAMEWORK_PATH


def page_comp_code_generation(page_name, page_data, input_param):
    pg_generator = PageClassTemplate(input_param)
    comp_generator = ComponentClassTemplate(input_param)

    db = ChromaDBConnector(f"{CRAFT_FRAMEWORK_PATH}/embed_data_gen/csv")
    db2 = ChromaDBConnector(f"{CRAFT_FRAMEWORK_PATH}/embed_data_gen/code")
    parser = ParseMethodToCsv()

    non_exist_methods, exist_page_code, page_data = retrieve_exist_code(page_name, page_data)

    # If the java file does not exist, then create it
    if exist_page_code == "":

        pg_code = pg_generator.generate(page_name, page_data)
        write_code_to_file(pg_code, f"{CRAFT_FRAMEWORK_PATH}", f"Output/pages/",
                           page_name + f"Page.java")
        parser.parse_full_data(f"{CRAFT_FRAMEWORK_PATH}/Output/pages",
                               f"{CRAFT_FRAMEWORK_PATH}/gen_code_csv/pages")
        db.vectordb_store_doc(f"{CRAFT_FRAMEWORK_PATH}/gen_code_csv/pages/{page_name}Page.csv")
        db2.vectordb_store_code(pg_code, page_name + "Page")

        comp_code = comp_generator.generate(page_name, page_data, pg_code)
        write_code_to_file(comp_code, f"{CRAFT_FRAMEWORK_PATH}/", f"Output/businesscomponents/",
                           page_name + f"Component.java")
        parser.parse_full_data(f"{CRAFT_FRAMEWORK_PATH}/Output/businesscomponents",
                               f"{CRAFT_FRAMEWORK_PATH}/gen_code_csv/businesscomponents")
        db.vectordb_store_doc(f"{CRAFT_FRAMEWORK_PATH}/gen_code_csv/businesscomponents/{page_name}Component.csv")
        db2.vectordb_store_code(comp_code, page_name + "Component")
        return comp_code
    # if the file is already there then check the methods
    else:
        # case when there are some methods that do not exist
        if not non_exist_methods.empty:
            page_name = inc_filename(page_name)
            pg_code = pg_generator.generate(page_name, non_exist_methods)
            write_code_to_file(pg_code, f"{CRAFT_FRAMEWORK_PATH}/", f"Output/pages/",
                               page_name + f"Page.java")
            parser.parse_full_data(f"{CRAFT_FRAMEWORK_PATH}/Output/pages",
                                   f"{CRAFT_FRAMEWORK_PATH}/gen_code_csv/pages")
            db.vectordb_store_doc(f"{CRAFT_FRAMEWORK_PATH}/gen_code_csv/pages/{page_name}Page.csv")
            db2.vectordb_store_code(pg_code, page_name + "Page")

            comp_code = comp_generator.generate(page_name, page_data, pg_code)
            write_code_to_file(comp_code, f"{CRAFT_FRAMEWORK_PATH}/", f"Output/businesscomponents/",
                               page_name + f"Component.java")
            parser.parse_full_data(f"{CRAFT_FRAMEWORK_PATH}/Output/businesscomponents",
                                   f"{CRAFT_FRAMEWORK_PATH}/gen_code_csv/businesscomponents")
            db.vectordb_store_doc(f"{CRAFT_FRAMEWORK_PATH}/gen_code_csv/businesscomponents/{page_name}Component.csv")
            db2.vectordb_store_code(comp_code, page_name + "Component")

            exist_comp_code = db2.get_doc_by_id(f"{page_name[:-1]}Component")['documents'][0] if len(
                db2.get_doc_by_id(f"{page_name[:-1]}Component")['documents']) > 0 else ""

            return exist_comp_code + "\n\n\n\n" + comp_code
        # case when all methods are present in file
        else:
            exist_comp_code = db2.get_doc_by_id(f"{page_name}Component")['documents'][0] if len(
                db2.get_doc_by_id(f"{page_name}Component")['documents']) > 0 else ""
            return exist_comp_code


def test_script_code_generation(page_name, comp_classes, comp_code, input_param):
    script_generator = TestScriptTemplate(input_param)
    db = ChromaDBConnector(f"{CRAFT_FRAMEWORK_PATH}/embed_data_gen/code")

    component_methods = comp_code

    tc_script_code = script_generator.generate(page_name, component_methods)
    write_code_to_file(tc_script_code, f"{CRAFT_FRAMEWORK_PATH}/", f"Output/testscripts/",
                       page_name + f"TestScript.java")


def inc_filename(file_name: str):
    new_file_name = (
        file_name[:-1] + str(int(file_name[-1]) + 1)
        if file_name[-1].isdigit()
        else file_name + "2"
    )
    return new_file_name
