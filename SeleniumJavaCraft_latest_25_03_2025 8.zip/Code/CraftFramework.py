import os.path

from Code.Framework_Integration import required_imports_old
from Code.parseClassCodeToCsv import ParseClassCodeToCsv
from Code.CraftScriptGenerator import *
from Code import PathConstants
from Code.ChromaDBConnector import ChromaDBConnector

CRAFT_FRAMEWORK_PATH = PathConstants.CRAFT_FRAMEWORK_PATH


def craft_generator(df_inter, input_param):

    if not os.path.exists(f"{CRAFT_FRAMEWORK_PATH}/csv_data"):
        os.makedirs(f"{CRAFT_FRAMEWORK_PATH}/csv_data")
    parser = ParseClassCodeToCsv()
    exclude_files = parser.parse_data(
        f"{CRAFT_FRAMEWORK_PATH}/FrameworkScripts/FrameworkFolder",
        f"{CRAFT_FRAMEWORK_PATH}/csv_data")
    print(exclude_files)

    if not os.path.exists(f"{CRAFT_FRAMEWORK_PATH}/embed_data_core"):
        db = ChromaDBConnector(f"{CRAFT_FRAMEWORK_PATH}/embed_data_core")
        db.vectordb_store_dir(f"{CRAFT_FRAMEWORK_PATH}/csv_data")

    input_param['reusable_class_names'] = required_imports_old(
        f"{CRAFT_FRAMEWORK_PATH}/FrameworkScripts/FrameworkFolder",
        f"{CRAFT_FRAMEWORK_PATH}/FrameworkScripts/ScriptsFolder", exclude_files)

    page_wise = df_inter.groupby("page", sort=False)
    comp_code = ""
    component_classes = []

    for page_name, page_data in page_wise:
        print(f"Processing Group '{page_name}':")
        print(page_data)
        comp_code += page_comp_code_generation(page_name, page_data, input_param)
        comp_code += "\n\n\n\n"
        component_classes.append(page_name)
    test_script_code_generation('Runner', component_classes, comp_code, input_param)
