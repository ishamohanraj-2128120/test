class CommonPrompt(object):
    def __init__(self):
        self.template_mapper = """
                        Task: Map each name in set1 to the most similar name in set2 using a one-to-one correspondence. Ignore set1 names without a similar counterpart in set2.

                        Example:
                            Input:
                                "set1": ["abc", "login", "home_page"],
                                "set2": ["aBc", "LoginPage", "clinic", "azPark", "Electron"]
                            
                            Output:
                                {{
                                    "abc": "aBc",
                                    "login": "LoginPage"
                                }}
                        
                        Guidelines:
                            1. Similarity is case-insensitive.
                            2. Output should be a JSON object with matched pairs.

                        Your Response should be strictly in JSON format.

                        set1: {crawled}
                        set2: {existing}
                        """

        self.template_object_identifier = """
As an advanced AI model, you are tasked with analyzing HTML content to find the best match for a given purpose. Your task involves the following steps:

1. **Analyze**: Carefully examine the provided purpose statement. Understand its intent and functional requirements.

2. **Compare**: Evaluate each HTML content in the given collection. Each content consists of:
   - element: The HTML element
   - locator: A unique identifier for the element
   - is_embedded: Boolean indicating if the element is within an iframe
   - embedded_to_switch_to_in_order: List of embedded sections to navigate, if applicable

3. **Identify**: Determine which content best matches the given purpose. Consider:
   - Structural similarity
   - Element types and attributes
   - Functional equivalence (especially for interactive elements)
   - Overall purpose alignment

4. **Extract**: From the best-matching content, extract the relevant information.

5. **Report**: Provide your findings in the following JSON format:
   {{
     "explanation": "<string>",
     "is_embedded": <boolean>,
     "locator": "<string>",
     "embedded_to_switch_to_in_order": [<string>, ...]
   }}

   Where:
   - explanation: A brief explanation of why the content is the best match
   - is_embedded: Boolean indicating if the best match is within an iframe
   - locator: The unique identifier for the matching element
   - embedded_to_switch_to_in_order: List of embedded sections to navigate (empty list if not applicable)

Important Notes:
- Focus on functional equivalence rather than exact replication.
- For interactive HTML, prioritize matches that preserve interactivity.
- If no suitable match is found, return null values in the JSON response.
- Explain your reasoning if the match is not obvious or if you encounter ambiguities.
- From now on no comments and no talking are needed. Just provide the JSON response.

Purpose: {purpose}

{context}
"""