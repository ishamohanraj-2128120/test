import pandas as pd

from Code.ChromaDBConnector import ChromaDBConnector

from Code.LLM import LLM
from Code.SeleniumJavaPrompt import SeleniumJavaPrompt
from Code.MergeSameClassCode import MergeSameClassCode


class PageClassTemplate:

    def __init__(self, input_param):
        self.model = LLM()
        self.input_param = input_param

    def generate(self, page_name, page_data):

        # prompt_decryption = PromptDecryption()
        prompt_instance = SeleniumJavaPrompt()
        # template_page_class = prompt_decryption.decrypt_prompt("template_page_class", prompt_instance)
        template_page_class = prompt_instance.template_page_class
        template_js_page_class = prompt_instance.template_js_page_class

        xpath_field_details = "When Xpath is found, create method of each action-object pair given in the form of 'Action - Object - Test data - locator'."\
                        "If field details have 'failure' in form of 'Action - Object - Test data - Failure - Input', do not create any method for this action instead of that add a comment with failure message and input message for each failure action, for example: //'failure':  , 'input': " \
                        "Follow the sequence of the field_details.\n"
        jspath_field_details = "If JSPath is found, use JavascriptExecutor to access the element in ShadowDOM(S) and create method to implement the same." \
                               "If field details have 'failure' in form of 'Action - Object - Test data - Failure - Input', do not create any method for this action instead of that add a comment with failure message and input message for each failure action, for example: //'failure':  , 'input': " \
                               "Follow the sequence of the field_details.\n"


        failed_steps = ["\n\t//The code for the following steps is not generated:\n"]
        priority_list = self.input_param['locatorPriority']
        priority_dict = {}
        for _, row in page_data.iterrows():

            if str(row['failure']).startswith("Invalid action"):
                failed_steps.append(
                    "\t//" + str(row['action']) + " - " + str(row['object']) + ". " + str(row['failure']) + "\n")
                continue

            locator = ''
            item = 0

            # if xpath IS present
            if not pd.isna(row['Xpath']):
                locator = row['Locator']
                if row['Xpath'].startswith("document"):
                    jspath_field_details += str(row['action']) + " - " + str(row['object']) + " - " + str(
                        row['data']) + " - JSpath: " + str(row['Xpath']) + "\n"
                else:
                    xpath_field_details += str(row['action']) + " - " + str(row['object']) + " - " + str(
                        row['data']) + " - Locator: " + str(row[locator]) + "\n"
                    priority_dict[str(row['action']) + " " + str(row['object'])] = locator
            # xpath not present
            else:
                xpath_field_details += str(row['action']) + " - " + str(row['object']) + " - " + str(
                    row['data']) + " - Failure message: " + str(
                    row['failure']) + " - Input message: " + str(row['input']) + "\n"

        db = ChromaDBConnector("../Data/embed_data_core")

        reusable_code_details = ""
        for class_name in self.input_param['reusable_class_names']['pages']:
            class_documents = db.get_doc_by_id(class_name)['documents']
            if class_documents:  # Check if the list is not empty
                reusable_code_details += class_documents[0] + '\n'

        input_variables = ["reusable_code_details",
                           "page_class", "field_details", "priority_dict"]
        if 'document.querySelector' in jspath_field_details:

            input_variables_dict = {'reusable_code_details': reusable_code_details, 'page_class': page_name,
                                    'field_details': jspath_field_details, 'priority_dict': priority_dict}
            output_qa_prompt_page = self.model.send_request(self.input_param, template_js_page_class, input_variables,
                                                  input_variables_dict)
        else:
            input_variables_dict = {'reusable_code_details': reusable_code_details, 'page_class': page_name,
                                    'field_details': xpath_field_details, 'priority_dict': priority_dict }
            output_qa_prompt_page = self.model.send_request(self.input_param, template_page_class, input_variables,
                                                  input_variables_dict)
        # input_variables_dict = {'reusable_code_details': reusable_code_details, 'page_class': page_name,
        #                         'field_details': field_details, 'priority_dict': priority_dict}
        #
        # output_qa_prompt_page = self.model.send_request(self.input_param, template_page_class, input_variables,
        #                                                 input_variables_dict)
        print(f"{page_name}Page class file generated")

        if len(failed_steps) > 1:
            merger = MergeSameClassCode()
            output_qa_prompt_page = merger.failed_steps_comments_last(output_qa_prompt_page, failed_steps)

        return output_qa_prompt_page
