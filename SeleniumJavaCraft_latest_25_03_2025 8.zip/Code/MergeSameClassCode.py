import re
from collections import OrderedDict

import javalang
import pandas as pd


class MergeSameClassCode:

    def __init__(self):
        pass

    def merge_java_pg_code(self, existing_code, new_methods_code, page_data):
        # Extract the class name from the existing code
        class_name = None
        class_declaration_index = None
        existing_locator_names = []

        for i, line in enumerate(existing_code.split('\n')):
            if line.strip().startswith("public class"):
                class_name = line.split()[-1].split("(")[0]
                class_declaration_index = i
                break

        for i, line in enumerate(existing_code.split('\n')):
            if line.strip().startswith("private By "):
                # capture only names of existing locators
                method_pattern = f"private By (\w+) ="
                match = re.search(method_pattern, line.strip())
                existing_locator_names.append(match.group(1))

        existing_code_lines = existing_code.split('\n')
        new_methods = []
        new_locators = []  # Initialize the list to capture new locators
        existing_methods = []

        # Capture methods and locators from the new code
        capturing_methods = False
        method_depth_existing = 0
        method_depth_new = 0
        current_method_lines = []
        current_locator_lines = []  # Initialize the list to capture new locators
        current_locator_names = []

        for line in new_methods_code.split('\n'):
            stripped_line = line.strip()

            if stripped_line.startswith("public void ") and (not stripped_line.startswith(f"public {class_name}(")):
                capturing_methods = True
            elif stripped_line.startswith("private By "):
                current_locator_lines.append(line)  # Capture new locators

            if capturing_methods:
                current_method_lines.append(line)

                if stripped_line.endswith("{") and (not stripped_line.startswith("}")):
                    method_depth_new += 1

                if stripped_line == "}":
                    method_depth_new -= 1
                    if method_depth_new == 0:
                        method_content = '\n'.join(current_method_lines)
                        new_methods.append(method_content)
                        current_method_lines = []
                        capturing_methods = False

        for line in existing_code_lines:
            stripped_line = line.strip()

            if stripped_line.startswith("public void ") and (not stripped_line.startswith(f"public {class_name}(")):
                capturing_methods = True

            if capturing_methods:
                current_method_lines.append(line)

                if stripped_line.endswith("{") and (not stripped_line.startswith("}")):
                    method_depth_existing += 1

                if stripped_line == "}":
                    method_depth_existing -= 1
                    if method_depth_existing == 0:
                        method_content = '\n'.join(current_method_lines)
                        existing_methods.append(method_content)
                        current_method_lines = []
                        capturing_methods = False

        # Check if locators already exist inside the class declaration and add only if not present
        if class_declaration_index is not None:
            for locator in current_locator_lines:

                if locator.strip().split(" ")[2] not in existing_locator_names:
                    new_locators.append(locator)  # Add new locators to the list
                    existing_code_lines.insert(class_declaration_index + 1, locator)

        # Create a dictionary to store the methods by method name
        new_methods_dict = {method.split('(')[0].strip().split(' ')[-1]: method for method in new_methods}
        new_methods_ordered_dict = OrderedDict(new_methods_dict)
        existing_methods_dict = {method.split('(')[0].strip().split(' ')[-1]: method for method in existing_methods}
        print(new_methods_dict, existing_methods_dict)

        # Arrange the existing methods and new methods according to the method sequence
        merged_methods = []

        for i, row in page_data.iterrows():
            if not pd.isna(row['method_name']):
                merged_methods.append(existing_methods_dict[row['method_name']])
            else:
                first_key, first_value = new_methods_ordered_dict.popitem(last=False)
                merged_methods.append(first_value)

        # Find the line where the constructor ends
        constructor_end_line = None
        for i, line in enumerate(existing_code_lines[class_declaration_index:]):
            if line.strip() == "}":
                constructor_end_line = class_declaration_index + i
                break

        # Insert the merged methods after the constructor end line
        merged_code_lines = existing_code_lines[
                            :constructor_end_line + 1] + merged_methods

        # Join the lines back into a single string
        merged_code = '\n'.join(merged_code_lines)
        merged_code += "\n}"
        print("Code Merged Successfully ")

        return merged_code

    def merge_java_comp_code(self, existing_code, new_methods_code):
        # Extract the class name from the existing code
        class_name = None
        class_declaration_index = None
        for i, line in enumerate(existing_code.split('\n')):
            if line.strip().startswith("public class"):
                class_name = line.split()[-1].split("(")[0]
                class_declaration_index = i
                break

        existing_code_lines = existing_code.split('\n')
        new_methods = []

        # Capture methods and locators from the new code
        capturing_methods = False
        method_depth_new = 0
        current_method_lines = []

        for line in new_methods_code.split('\n'):
            stripped_line = line.strip()

            if stripped_line.startswith("public void") and (not stripped_line.startswith(f"public {class_name}(")):
                capturing_methods = True

            if capturing_methods:
                current_method_lines.append(line)

                if stripped_line.endswith("{") and (not stripped_line.startswith("}")):
                    method_depth_new += 1

                if stripped_line == "}":
                    method_depth_new -= 1
                    if method_depth_new == 0:
                        method_content = '\n'.join(current_method_lines)
                        new_methods.append(method_content)
                        current_method_lines = []
                        capturing_methods = False

        # Find the line where the constructor ends
        constructor_end_line = None
        for i, line in enumerate(existing_code_lines[class_declaration_index:]):
            if line.strip() == "}":
                constructor_end_line = class_declaration_index + i
                break

        # Insert the merged methods after the constructor end line
        merged_code_lines = existing_code_lines[
                            :constructor_end_line + 1] + new_methods

        # Join the lines back into a single string
        merged_code = '\n'.join(merged_code_lines)
        merged_code += "\n}"
        print("Code Merged Successfully ")

        return merged_code

    def failed_steps_comments(self, code, comments):

        existing_code_lines = code.split("\n")

        # Find the line where the constructor ends
        constructor_end_line = None
        for i, line in enumerate(existing_code_lines):
            if line.strip() == "}":
                constructor_end_line = i
                break

        # Insert the merged methods after the constructor end linea
        remaining_code = existing_code_lines[constructor_end_line + 1:]

        merged_code_lines = (
                existing_code_lines[: constructor_end_line + 1] + comments + remaining_code
        )

        merged_code = "\n".join(merged_code_lines)
        return merged_code

    def failed_steps_comments_last(self, code, comments):

        existing_code_lines = code.split("\n")
        last_line = len(existing_code_lines) - 1
        if existing_code_lines[last_line].strip() == "}":
            merged_code_lines = existing_code_lines[:last_line] + comments
        else:
            merged_code_lines = existing_code_lines[:last_line - 1] + comments
        merged_code = "\n".join(merged_code_lines) + "\n}"
        return merged_code


######################################################## NEW MERGER #########################################################

import jpype

# Set the path to the JavaParser JAR file
jar_path = r'..\Data\javaparser\javaparser-core-3.25.4.jar'
jpype.startJVM(classpath=[jar_path])

from jpype import JClass

# Import the required JavaParser classes
CompilationUnit = JClass('com.github.javaparser.ast.CompilationUnit')
StaticJavaParser = JClass('com.github.javaparser.StaticJavaParser')
ImportDeclaration = JClass('com.github.javaparser.ast.ImportDeclaration')
ClassOrInterfaceDeclaration = JClass('com.github.javaparser.ast.body.ClassOrInterfaceDeclaration')
FieldDeclaration = JClass('com.github.javaparser.ast.body.FieldDeclaration')
VariableDeclarator = JClass('com.github.javaparser.ast.body.VariableDeclarator')
MethodDeclaration = JClass('com.github.javaparser.ast.body.MethodDeclaration')
ConstructorDeclaration = JClass('com.github.javaparser.ast.body.ConstructorDeclaration')
BlockStmt = JClass('com.github.javaparser.ast.stmt.BlockStmt')
ExpressionStmt = JClass('com.github.javaparser.ast.stmt.ExpressionStmt')
LineComment = JClass('com.github.javaparser.ast.comments.LineComment')
BlockComment = JClass('com.github.javaparser.ast.comments.BlockComment')
JavadocComment = JClass('com.github.javaparser.ast.comments.JavadocComment')
PackageDeclaration = JClass('com.github.javaparser.ast.PackageDeclaration')
AnnotationExpr = JClass('com.github.javaparser.ast.expr.AnnotationExpr')
MarkerAnnotationExpr = JClass('com.github.javaparser.ast.expr.MarkerAnnotationExpr')
NormalAnnotationExpr = JClass('com.github.javaparser.ast.expr.NormalAnnotationExpr')
SingleMemberAnnotationExpr = JClass('com.github.javaparser.ast.expr.SingleMemberAnnotationExpr')
TypeParameter = JClass('com.github.javaparser.ast.type.TypeParameter')
ClassOrInterfaceType = JClass('com.github.javaparser.ast.type.ClassOrInterfaceType')
PrimitiveType = JClass('com.github.javaparser.ast.type.PrimitiveType')
WildcardType = JClass('com.github.javaparser.ast.type.WildcardType')
VariableDeclarationExpr = JClass('com.github.javaparser.ast.expr.VariableDeclarationExpr')

def merge_java_code(original_code, generated_code):
    original_compilation_unit = StaticJavaParser.parse(original_code)
    generated_compilation_unit = StaticJavaParser.parse(generated_code)

    merge_outside_class(original_compilation_unit, generated_compilation_unit)
    merge_at_class_level(original_compilation_unit, generated_compilation_unit)
    merge_annotations_for_parameters(original_compilation_unit, generated_compilation_unit)
    merge_annotations_for_type_uses(original_compilation_unit, generated_compilation_unit)

    return str(original_compilation_unit.toString())


def merge_outside_class(original_compilation_unit, generated_compilation_unit):
    generated_child_nodes = list(generated_compilation_unit.getChildNodes())

    for node in generated_child_nodes:
        if isinstance(node, ImportDeclaration):
            if not original_compilation_unit.getImports().contains(node):
                original_compilation_unit.getImports().add(node)
                append_comment(node, "New")
        elif isinstance(node, ClassOrInterfaceDeclaration):
            if not original_compilation_unit.getClassByName(node.getNameAsString()).isPresent():
                original_compilation_unit.getTypes().add(node)
                append_comment(node, "New")
        elif isinstance(node, PackageDeclaration):
            merge_package_declaration(original_compilation_unit, node)


def merge_package_declaration(original_compilation_unit, generated_package_declaration):
    if not original_compilation_unit.getPackageDeclaration().isPresent() or \
            original_compilation_unit.getPackageDeclaration().get().getName().asString() != generated_package_declaration.getName().asString():
        original_compilation_unit.setPackageDeclaration(generated_package_declaration)
        append_comment(generated_package_declaration, "New")

    # Check annotation declarations for package declarations
    if original_compilation_unit.getPackageDeclaration().isPresent() and generated_package_declaration.getAnnotations().isNonEmpty():
        merge_annotations(original_compilation_unit.getPackageDeclaration().get(), generated_package_declaration)


def merge_at_class_level(original_compilation_unit, generated_compilation_unit):
    for generated_class in generated_compilation_unit.findAll(ClassOrInterfaceDeclaration):
        original_class = original_compilation_unit.getClassByName(generated_class.getNameAsString()).orElse(None)

        if original_class:
            merge_class_keywords_and_extensions(original_class, generated_class)
            merge_annotations(original_class, generated_class)
            merge_constructors(original_class, generated_class)
            merge_methods(original_class, generated_class)
            merge_fields(original_class, generated_class)
            merge_class_level_statements(original_class, generated_class)
        else:
            original_compilation_unit.getTypes().add(generated_class)
            append_comment(generated_class, "New")


def merge_class_keywords_and_extensions(original_class, generated_class):
    if original_class.getModifiers() != generated_class.getModifiers() or \
            original_class.getExtendedTypes() != generated_class.getExtendedTypes() or \
            original_class.getImplementedTypes() != generated_class.getImplementedTypes():
        original_class.setModifiers(generated_class.getModifiers())
        original_class.setExtendedTypes(generated_class.getExtendedTypes())
        original_class.setImplementedTypes(generated_class.getImplementedTypes())
        append_comment(original_class, "Modified")


def merge_annotations(original_node, generated_node):
    if isinstance(original_node, (FieldDeclaration, VariableDeclarationExpr)):
        original_annotations = original_node.getAnnotations()
        generated_annotations = generated_node.getAnnotations()
    else:
        original_annotations = original_node.getAnnotations()
        generated_annotations = generated_node.getAnnotations()

    for generated_annotation in generated_annotations:
        original_annotation = original_annotations.stream() \
            .filter(lambda a: a.getName().asString() == generated_annotation.getName().asString()) \
            .findFirst().orElse(None)

        if original_annotation:
            if original_annotation.toString() != generated_annotation.toString():
                original_annotations.remove(original_annotation)
                original_annotations.add(generated_annotation)
                append_comment(generated_annotation, "Modified")
        else:
            original_annotations.add(generated_annotation)
            append_comment(generated_annotation, "New")


def merge_constructors(original_class, generated_class):
    for generated_constructor in generated_class.getConstructors():
        original_constructor = original_class.getConstructors().stream() \
            .filter(lambda c: c.getParameters().size() == generated_constructor.getParameters().size() and
                              all(p1.getType().asString() == p2.getType().asString()
                                  for p1, p2 in zip(c.getParameters(), generated_constructor.getParameters()))) \
            .findFirst().orElse(None)

        if original_constructor:
            merge_constructor_keywords_and_parameters(original_constructor, generated_constructor)
            merge_annotations(original_constructor, generated_constructor)
            merge_statements(original_constructor.getBody(), generated_constructor.getBody())
        else:
            original_class.getMembers().add(generated_constructor)
            append_comment(generated_constructor, "New")


def merge_constructor_keywords_and_parameters(original_constructor, generated_constructor):
    if original_constructor.getModifiers() != generated_constructor.getModifiers() or \
            original_constructor.getParameters() != generated_constructor.getParameters() or \
            original_constructor.getThrownExceptions() != generated_constructor.getThrownExceptions():
        original_constructor.setModifiers(generated_constructor.getModifiers())
        original_constructor.setParameters(generated_constructor.getParameters())
        original_constructor.setThrownExceptions(generated_constructor.getThrownExceptions())
        append_comment(original_constructor, "Modified")


def merge_methods(original_class, generated_class):
    for generated_method in generated_class.getMethods():
        method_name = generated_method.getNameAsString()
        method_params = [param.getType().asString() for param in generated_method.getParameters()]

        original_methods = original_class.getMembers().stream() \
            .filter(lambda member: isinstance(member, MethodDeclaration)
                                   and member.getNameAsString() == method_name
                                   and [param.getType().asString() for param in
                                        member.getParameters()] == method_params) \
            .collect(jpype.java.util.stream.Collectors.toList())

        if original_methods:
            original_method = original_methods[0]
            merge_method_keywords_and_parameters(original_method, generated_method)
            merge_annotations(original_method, generated_method)
            merge_variable_declarations(original_method, generated_method)
            merge_statements(original_method.getBody().orElse(None), generated_method.getBody().orElse(None))
        else:
            original_class.getMembers().add(generated_method)
            append_comment(generated_method, "New")


def merge_method_keywords_and_parameters(original_method, generated_method):
    if original_method.getModifiers() != generated_method.getModifiers() or \
            original_method.getParameters() != generated_method.getParameters() or \
            original_method.getType() != generated_method.getType() or \
            original_method.getTypeParameters() != generated_method.getTypeParameters() or \
            original_method.getThrownExceptions() != generated_method.getThrownExceptions():
        original_method.setModifiers(generated_method.getModifiers())
        original_method.setParameters(generated_method.getParameters())
        original_method.setType(generated_method.getType())
        original_method.setTypeParameters(generated_method.getTypeParameters())
        original_method.setThrownExceptions(generated_method.getThrownExceptions())
        append_comment(original_method, "Modified")


def merge_variable_declarations(original_node, generated_node):
    for generated_variable in generated_node.findAll(VariableDeclarator):
        original_variable = original_node.findAll(VariableDeclarator).stream().filter(
            lambda v: v.getNameAsString() == generated_variable.getNameAsString()).findFirst().orElse(None)

        if original_variable:
            merge_variable_value(original_variable, generated_variable)
            merge_variable_keywords_and_type(original_variable, generated_variable)

            original_declaration = original_variable.findAncestor(FieldDeclaration.class_, VariableDeclarationExpr.class_).orElse(None)
            generated_declaration = generated_variable.findAncestor(FieldDeclaration.class_, VariableDeclarationExpr.class_).orElse(None)

            if original_declaration and generated_declaration:
                merge_annotations(original_declaration, generated_declaration)
        else:
            if original_node.getBody().isPresent() and generated_variable.findAncestor(
                    FieldDeclaration.class_).isPresent():
                original_node.getBody().get().addStatement(0, generated_variable.findAncestor(
                    FieldDeclaration.class_).get())
                append_comment(generated_variable, "New")


def merge_variable_value(original_variable, generated_variable):
    generated_value = generated_variable.getInitializer().orElse(None)
    original_value = original_variable.getInitializer().orElse(None)

    if original_value and generated_value and original_value.toString() != generated_value.toString():
        original_declaration = original_variable.findAncestor(FieldDeclaration.class_, VariableDeclarationExpr.class_).orElse(None)
        if original_declaration:
            append_comment(original_declaration, f"Modified value in the generated code is {generated_value}")


def merge_variable_keywords_and_type(original_variable, generated_variable):
    original_declaration = original_variable.findAncestor(FieldDeclaration.class_, VariableDeclarationExpr.class_).orElse(None)
    generated_declaration = generated_variable.findAncestor(FieldDeclaration.class_, VariableDeclarationExpr.class_).orElse(None)

    if original_declaration and generated_declaration:
        if original_declaration.getModifiers() != generated_declaration.getModifiers() or \
                original_variable.getType() != generated_variable.getType():
            original_declaration.setModifiers(generated_declaration.getModifiers())
            original_variable.setType(generated_variable.getType())
            append_comment(original_variable, "Modified")


def merge_fields(original_class, generated_class):
    for generated_field in generated_class.getFields():
        original_fields = original_class.getMembers().stream() \
            .filter(lambda member: isinstance(member, FieldDeclaration)
                                   and member.getVariable(0).getNameAsString() == generated_field.getVariable(
            0).getNameAsString()) \
            .collect(jpype.java.util.stream.Collectors.toList())

        if original_fields:
            original_field = original_fields[0]
            merge_variable_value(original_field.getVariable(0), generated_field.getVariable(0))
            merge_field_keywords_and_type(original_field, generated_field)
            merge_annotations(original_field, generated_field)
        else:
            original_class.getMembers().add(generated_field)
            append_comment(generated_field, "New")


def merge_field_keywords_and_type(original_field, generated_field):
    if original_field.getModifiers() != generated_field.getModifiers() or \
            original_field.getVariable(0).getType() != generated_field.getVariable(0).getType():
        original_field.setModifiers(generated_field.getModifiers())
        original_field.getVariable(0).setType(generated_field.getVariable(0).getType())
        append_comment(original_field, "Modified")


def merge_class_level_statements(original_class, generated_class):
    new_class_statements = []

    for generated_node in generated_class.getChildNodes():
        if isinstance(generated_node, (BlockStmt, ExpressionStmt)):
            merge_statements(original_class, generated_node, new_class_statements)

    for statement in new_class_statements:
        original_class.addMember(statement)
        append_comment(statement, "New")

def merge_statements(original_node, generated_node, new_statements=None):
    if new_statements is None:
        new_statements = []

    if original_node and generated_node:
        for generated_child_node in generated_node.getChildNodes():
            if isinstance(generated_child_node, (BlockStmt, ExpressionStmt)):
                original_child_node = original_node.getChildNodes().stream().filter(
                    lambda n: n.toString() == generated_child_node.toString()).findFirst().orElse(None)

                if original_child_node:
                    if original_child_node.toString() != generated_child_node.toString():
                        original_node.replace(original_child_node, generated_child_node)
                        append_comment(generated_child_node, "Modified")
                else:
                    new_statements.append(generated_child_node)

        for index, statement in enumerate(new_statements):
            original_node.addStatement(index, statement)
            append_comment(statement, "New")


def merge_annotations_for_parameters(original_compilation_unit, generated_compilation_unit):
    for generated_class in generated_compilation_unit.findAll(ClassOrInterfaceDeclaration):
        original_class = original_compilation_unit.getClassByName(
            generated_class.getNameAsString()).orElse(None)

        if original_class:
            merge_annotations_for_method_parameters(original_class, generated_class)
            merge_annotations_for_constructor_parameters(original_class, generated_class)


def merge_annotations_for_method_parameters(original_class, generated_class):
    for generated_method in generated_class.getMethods():
        method_name = generated_method.getNameAsString()
        method_params = [param.getType().asString() for param in generated_method.getParameters()]

        original_methods = original_class.getMembers().stream() \
            .filter(lambda member: isinstance(member, MethodDeclaration)
                                   and member.getNameAsString() == method_name
                                   and [param.getType().asString() for param in
                                        member.getParameters()] == method_params) \
            .collect(jpype.java.util.stream.Collectors.toList())

        if original_methods:
            original_method = original_methods[0]

            for generated_param, original_param in zip(generated_method.getParameters(),
                                                       original_method.getParameters()):
                merge_annotations(original_param, generated_param)


def merge_annotations_for_constructor_parameters(original_class, generated_class):
    for generated_constructor in generated_class.getConstructors():
        original_constructor = original_class.getConstructors().stream() \
            .filter(lambda c: c.getParameters().size() == generated_constructor.getParameters().size() and
                              all(p1.getType().asString() == p2.getType().asString()
                                  for p1, p2 in zip(c.getParameters(), generated_constructor.getParameters()))) \
            .findFirst().orElse(None)

        if original_constructor:
            for generated_param, original_param in zip(generated_constructor.getParameters(),
                                                       original_constructor.getParameters()):
                merge_annotations(original_param, generated_param)


def merge_annotations_for_type_uses(original_compilation_unit, generated_compilation_unit):
    for generated_class in generated_compilation_unit.findAll(ClassOrInterfaceDeclaration):
        original_class = original_compilation_unit.getClassByName(
            generated_class.getNameAsString()).orElse(None)

        if original_class:
            merge_annotations_for_type_parameters(original_class, generated_class)
            merge_annotations_for_field_types(original_class, generated_class)
            merge_annotations_for_method_return_types(original_class, generated_class)
            merge_annotations_for_method_type_parameters(original_class, generated_class)
            merge_annotations_for_method_parameter_types(original_class, generated_class)
            merge_annotations_for_constructor_type_parameters(original_class, generated_class)
            merge_annotations_for_constructor_parameter_types(original_class, generated_class)


def merge_annotations_for_type_parameters(original_class, generated_class):
    for generated_type_param in generated_class.getTypeParameters():
        original_type_param = original_class.getTypeParameters().stream() \
            .filter(lambda tp: tp.getNameAsString() == generated_type_param.getNameAsString()) \
            .findFirst().orElse(None)

        if original_type_param:
            merge_annotations(original_type_param, generated_type_param)

            for generated_bound, original_bound in zip(generated_type_param.getTypeBound(),
                                                       original_type_param.getTypeBound()):
                merge_annotations(original_bound, generated_bound)


def merge_annotations_for_field_types(original_class, generated_class):
    for generated_field in generated_class.getFields():
        original_field = original_class.getFields().stream() \
            .filter(
            lambda f: f.getVariable(0).getNameAsString() == generated_field.getVariable(0).getNameAsString()) \
            .findFirst().orElse(None)

        if original_field:
            merge_annotations_for_type(original_field.getCommonType(), generated_field.getCommonType())


def merge_annotations_for_method_return_types(original_class, generated_class):
    for generated_method in generated_class.getMethods():
        original_method = original_class.getMethods().stream() \
            .filter(lambda m: m.getNameAsString() == generated_method.getNameAsString() and
                              m.getParameters().size() == generated_method.getParameters().size() and
                              all(p1.getType().asString() == p2.getType().asString()
                                  for p1, p2 in zip(m.getParameters(), generated_method.getParameters()))) \
            .findFirst().orElse(None)

        if original_method:
            merge_annotations_for_type(original_method.getType(), generated_method.getType())


def merge_annotations_for_method_type_parameters(original_class, generated_class):
    for generated_method in generated_class.getMethods():
        original_method = original_class.getMethods().stream() \
            .filter(lambda m: m.getNameAsString() == generated_method.getNameAsString() and
                              m.getParameters().size() == generated_method.getParameters().size() and
                              all(p1.getType().asString() == p2.getType().asString()
                                  for p1, p2 in zip(m.getParameters(), generated_method.getParameters()))) \
            .findFirst().orElse(None)

        if original_method:
            for generated_type_param, original_type_param in zip(generated_method.getTypeParameters(),
                                                                 original_method.getTypeParameters()):
                merge_annotations(original_type_param, generated_type_param)

                for generated_bound, original_bound in zip(generated_type_param.getTypeBound(),
                                                           original_type_param.getTypeBound()):
                    merge_annotations(original_bound, generated_bound)


def merge_annotations_for_method_parameter_types(original_class, generated_class):
    for generated_method in generated_class.getMethods():
        original_method = original_class.getMethods().stream() \
            .filter(lambda m: m.getNameAsString() == generated_method.getNameAsString() and
                              m.getParameters().size() == generated_method.getParameters().size() and
                              all(p1.getType().asString() == p2.getType().asString()
                                  for p1, p2 in zip(m.getParameters(), generated_method.getParameters()))) \
            .findFirst().orElse(None)

        if original_method:
            for generated_param, original_param in zip(generated_method.getParameters(),
                                                       original_method.getParameters()):
                merge_annotations_for_type(original_param.getType(), generated_param.getType())


def merge_annotations_for_constructor_type_parameters(original_class, generated_class):
    for generated_constructor in generated_class.getConstructors():
        original_constructor = original_class.getConstructors().stream() \
            .filter(lambda c: c.getParameters().size() == generated_constructor.getParameters().size() and
                              all(p1.getType().asString() == p2.getType().asString()
                                  for p1, p2 in zip(c.getParameters(), generated_constructor.getParameters()))) \
            .findFirst().orElse(None)

        if original_constructor:
            for generated_type_param, original_type_param in zip(generated_constructor.getTypeParameters(),
                                                                 original_constructor.getTypeParameters()):
                merge_annotations(original_type_param, generated_type_param)

                for generated_bound, original_bound in zip(generated_type_param.getTypeBound(),
                                                           original_type_param.getTypeBound()):
                    merge_annotations(original_bound, generated_bound)


def merge_annotations_for_constructor_parameter_types(original_class, generated_class):
    for generated_constructor in generated_class.getConstructors():
        original_constructor = original_class.getConstructors().stream() \
            .filter(lambda c: c.getParameters().size() == generated_constructor.getParameters().size() and
                              all(p1.getType().asString() == p2.getType().asString()
                                  for p1, p2 in zip(c.getParameters(), generated_constructor.getParameters()))) \
            .findFirst().orElse(None)

        if original_constructor:
            for generated_param, original_param in zip(generated_constructor.getParameters(),
                                                       original_constructor.getParameters()):
                merge_annotations_for_type(original_param.getType(), generated_param.getType())


def merge_annotations_for_type(original_type, generated_type):
    if isinstance(generated_type, (ClassOrInterfaceType, PrimitiveType, WildcardType)):
        for generated_annotation in generated_type.getAnnotations():
            original_annotation = original_type.getAnnotations().stream() \
                .filter(lambda a: a.getName().asString() == generated_annotation.getName().asString()) \
                .findFirst().orElse(None)

            if original_annotation:
                if original_annotation.toString() != generated_annotation.toString():
                    original_type.getAnnotations().remove(original_annotation)
                    original_type.getAnnotations().add(generated_annotation)
                    append_comment(generated_annotation, "Modified")
            else:
                original_type.getAnnotations().add(generated_annotation)
                append_comment(generated_annotation, "New")


def append_comment(node, comment_text):
    existing_comment = node.getComment().orElse(None)
    if existing_comment:
        if isinstance(existing_comment, LineComment):
            new_comment_text = f"{existing_comment.getContent()} {comment_text}"
            node.setComment(LineComment(new_comment_text))
        elif isinstance(existing_comment, BlockComment):
            new_comment_text = f"{existing_comment.getContent()} {comment_text}"
            node.setComment(BlockComment(new_comment_text))
        elif isinstance(existing_comment, JavadocComment):
            new_comment_text = f"{existing_comment.getContent()} {comment_text}"
            node.setComment(JavadocComment(new_comment_text))
        else:
            new_comment_text = f"{existing_comment.toString()} {comment_text}"
            node.setComment(LineComment(new_comment_text))
    else:
        node.setComment(LineComment(comment_text))
